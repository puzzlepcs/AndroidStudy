package com.example.gaheehan.slidinglecture;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    LinearLayout page; //애니매이션을 동작 시킬 리니어 레이아웃
    Animation translateLeft, translateRight;
    Button button; //클릭시 글자 바뀌는것 해야 해


    boolean isPageOpen = false; //오픈되지 않음


    Button go, right, left;
    EditText uri;
    WebView wv;
    View.OnClickListener cl;
    String weburi;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    page = (LinearLayout)findViewById(R.id.page); //페이지를 찾아준다.
            //리니어 레이아웃으로 형변환            //context객체?
    translateLeft = AnimationUtils.loadAnimation(this,R.anim.translate_left);
    //애니매이션 translateLeft는 애니유틸스로 로드하고, 위와 같은 아이디로 만들어 놨다 말하기
    translateRight = AnimationUtils.loadAnimation(this, R.anim.translate_right);

    SlidingAnimationListener listener = new SlidingAnimationListener();
        //리스너 구현 후 애니매이션 객체에 등록해야 함
    translateLeft.setAnimationListener(listener);
    translateRight.setAnimationListener(listener); //이렇게 설정해주면 left right
        //실행되는 시점에 아래에 구현한 end 파트 실행됨

        button = (Button)findViewById(R.id.button); //버튼도 찾아준다
        button.setOnClickListener(new View.OnClickListener(){ //온클릭리스너로 버튼 클릭 시 동작하도록 한다.
            @Override
            public void onClick(View v){
                if(isPageOpen){ //페이지 오픈되어 있음, 닫아줘야 하니까 right동작
                    page.startAnimation(translateRight);
                }else{ //오픈 안되어 있으면
                    page.setVisibility(View.VISIBLE);
                    page.startAnimation(translateLeft); //다시 안보이게 해야하는데 리스너 설정해야
                }
            }
        });


        go = (Button) findViewById(R.id.go);
        right = (Button) findViewById(R.id.right);
        left = (Button) findViewById(R.id.left);
        LinearLayout button2 = (LinearLayout)findViewById(R.id.button2);
        uri = (EditText) findViewById(R.id.uri);
        wv = (WebView) findViewById(R.id.wv);
        wv.setWebViewClient(new MyWeb());



        cl = new View.OnClickListener(){
            @Override
            public void onClick(View v){
                switch (v.getId()){
                    case R.id.go:
                        weburi = uri.getText().toString();
                        if(weburi.startsWith("http://")){
                            wv.loadUrl(weburi);
                        }else{
                            wv.loadUrl("http://" + weburi);
                        }
                        break;
                    case R.id.left:
                        wv.goBack();
                        break;
                    case R.id.right:
                        wv.goForward();


                }
            }
        };
        go.setOnClickListener(cl);
        right.setOnClickListener(cl);
        left.setOnClickListener(cl);


    }
    //이너클래스 만들어서 애니매이션 끝날 때 만들어주기
    class SlidingAnimationListener implements Animation.AnimationListener{
//리스너 구현 후 애니매이션 객체에 등록해야 함  //리스너 설정해주면 콜백함수
        @Override
        public void onAnimationStart(Animation animation) {

        }

        @Override //애니매이션이 끝나는 시점에
        public void onAnimationEnd(Animation animation) {
            if(isPageOpen){ //만약 페이지가 열려있는 상태라면
                page.setVisibility(View.INVISIBLE); //안보이게 만들어라

                button.setText("open"); //닫혀있는 상태니까 위에 글자는 오픈으로 변경
                isPageOpen = false;
            }else{ //아니라면
                button.setText("close"); //닫기라고 해줌 (페이지 오픈이 아닌 상태)
                isPageOpen= true;
            }
        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    }

    class MyWeb extends WebViewClient implements com.example.gaheehan.slidinglecture.MyWeb {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url){
            return super.shouldOverrideUrlLoading(view, url);
        }
    }

}
