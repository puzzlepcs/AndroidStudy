package com.example.gaheehan.slidinglecture;

interface MyWeb {
}
